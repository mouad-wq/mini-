# 🚀 Azure Node App — Node 22 LTS + GitHub Actions

Application web **Express.js** prête à déployer sur **Azure App Service** (Linux, Node 22 LTS) via un pipeline **GitHub Actions** entièrement automatisé.

---

## 📁 Structure du projet

```
azure-node-app/
├── .github/
│   └── workflows/
│       └── azure-deploy.yml   ← Pipeline CI/CD (Build → Test → Deploy)
├── public/
│   └── index.html             ← Interface frontend (servie statiquement)
├── src/
│   ├── app.js                 ← Serveur Express (routes + middlewares)
│   └── app.test.js            ← Tests d'intégration (Jest + supertest)
├── .env.example               ← Modèle des variables d'environnement
├── .gitignore
└── package.json
```

---

## ⚙️ Démarrage en local

```bash
# 1. Cloner le dépôt
git clone https://github.com/<votre-user>/<votre-repo>.git
cd azure-node-app

# 2. Installer les dépendances
npm install

# 3. Configurer les variables d'environnement
cp .env.example .env

# 4. Lancer le serveur en mode développement
npm run dev
```

L'application est accessible sur [http://localhost:3000](http://localhost:3000).

---

## ☁️ Déploiement sur Azure App Service

### Étape 1 — Créer l'App Service

1. Se connecter au [portail Azure](https://portal.azure.com)
2. Aller dans **Créer une ressource** → **App Service**
3. Renseigner les paramètres suivants :

   | Champ | Valeur |
   |---|---|
   | Nom | `votre-app-name` *(doit être unique)* |
   | Runtime stack | `Node 22 LTS` |
   | Système d'exploitation | `Linux` |
   | Plan tarifaire | `Free F1` ou supérieur |

### Étape 2 — Récupérer le Publish Profile

1. Dans votre App Service → **Vue d'ensemble**
2. Cliquer sur **Télécharger le profil de publication**
3. Ouvrir le fichier `.PublishSettings` et copier tout son contenu

### Étape 3 — Configurer le secret GitHub

1. Aller dans votre dépôt GitHub → **Settings** → **Secrets and variables** → **Actions**
2. Créer un nouveau secret :
   - **Nom** : `AZURE_WEBAPP_PUBLISH_PROFILE`
   - **Valeur** : coller le contenu du fichier `.PublishSettings`

### Étape 4 — Mettre à jour le workflow

Dans `.github/workflows/azure-deploy.yml`, remplacer la valeur de `AZURE_WEBAPP_NAME` :

```yaml
env:
  AZURE_WEBAPP_NAME: 'votre-app-name'   # ← Votre nom d'App Service
```

### Étape 5 — Déclencher le déploiement

```bash
git add .
git commit -m "feat: configuration déploiement Azure"
git push origin main
```

Le pipeline se lance automatiquement. Vous pouvez suivre sa progression dans l'onglet **Actions** de votre dépôt GitHub.

---

## 🔗 Endpoints disponibles

| Méthode | Route | Description |
|---|---|---|
| `GET` | `/` | Interface frontend HTML |
| `GET` | `/health` | Vérification de l'état du serveur *(utilisé par Azure)* |
| `GET` | `/api/info` | Métadonnées de l'application |

---

## 🧪 Tests

```bash
npm test
```

Les tests vérifient les routes `/health` et `/api/info` via Jest et supertest. Un rapport de couverture est généré dans le dossier `coverage/`.

---

## 🌿 Variables d'environnement

Configurer ces variables dans Azure : **App Service** → **Configuration** → **Paramètres d'application**.

| Clé | Exemple | Description |
|---|---|---|
| `NODE_ENV` | `production` | Environnement d'exécution |
| `APP_NAME` | `Mon Application` | Nom affiché dans l'API |
| `PORT` | *(géré par Azure)* | Port d'écoute *(ne pas modifier)* |

---

## ✅ Pipeline CI/CD — Vue d'ensemble

```
Push sur main
      │
      ▼
┌─────────────────────────────┐
│  Job 1 : Build & Test       │
│  • npm ci                   │
│  • npm test                 │
│  • Upload artefact          │
└──────────────┬──────────────┘
               │ (si succès)
               ▼
┌─────────────────────────────┐
│  Job 2 : Deploy             │
│  • npm ci --omit=dev        │
│  • azure/webapps-deploy@v3  │
└─────────────────────────────┘
```

> **Note :** Le déploiement n'a lieu que lors d'un push direct sur `main`. Les Pull Requests déclenchent uniquement le Build & Test.
