/**
 * app.js — Point d'entrée principal du serveur Express
 *
 * Ce fichier configure et démarre le serveur HTTP de l'application.
 * Il expose trois points d'accès :
 *   - GET /health     : Vérification de l'état de l'application (utilisé par Azure)
 *   - GET /api/info   : Informations générales sur l'application
 *   - GET *           : Sert le fichier index.html (compatibilité SPA)
 */

'use strict';

const express = require('express');
const path    = require('path');

// ─── Initialisation ────────────────────────────────────────────────────────────

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Middlewares globaux ────────────────────────────────────────────────────────

app.use(express.json());                                          // Parsing JSON
app.use(express.urlencoded({ extended: true }));                  // Parsing form-data
app.use(express.static(path.join(__dirname, '../public')));       // Fichiers statiques

// ─── Routes ────────────────────────────────────────────────────────────────────

/**
 * Health check — vérifié automatiquement par Azure App Service.
 * Retourne l'environnement, l'heure serveur et la version de Node.
 */
app.get('/health', (_req, res) => {
  res.status(200).json({
    status:      'healthy',
    environment: process.env.NODE_ENV || 'development',
    timestamp:   new Date().toISOString(),
    node:        process.version,
  });
});

/**
 * Informations applicatives — utile pour les dashboards et le monitoring.
 */
app.get('/api/info', (_req, res) => {
  res.status(200).json({
    app:         process.env.APP_NAME  || 'Azure Node App',
    version:     '1.0.0',
    environment: process.env.NODE_ENV  || 'development',
  });
});

/**
 * Fallback SPA — toutes les routes inconnues renvoient vers le frontend.
 */
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ─── Démarrage du serveur ───────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`✅ Serveur démarré sur le port ${PORT}`);
  console.log(`🌍 Environnement : ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app; // Exporté pour les tests Jest
