/**
 * app.test.js — Tests d'intégration des routes de l'API
 *
 * Vérifie que les endpoints principaux répondent correctement.
 * Framework : Jest + supertest
 *
 * Lancer les tests :
 *   npm test
 */

'use strict';

const request = require('supertest');
const app     = require('../src/app');

// ─── Suite : Routes API ─────────────────────────────────────────────────────────

describe('Routes API', () => {

  /**
   * Health check : doit retourner un statut 200 avec les informations serveur.
   */
  test('GET /health → 200 avec statut "healthy"', async () => {
    const res = await request(app).get('/health');

    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('healthy');
    expect(res.body).toHaveProperty('node');
    expect(res.body).toHaveProperty('timestamp');
    expect(res.body).toHaveProperty('environment');
  });

  /**
   * Informations applicatives : doit retourner les métadonnées de l'app.
   */
  test('GET /api/info → 200 avec les informations de l\'application', async () => {
    const res = await request(app).get('/api/info');

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('version');
    expect(res.body).toHaveProperty('app');
    expect(res.body).toHaveProperty('environment');
  });

});
